using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace warehouse.Core
{
    public class corePickupArea : MonoBehaviour
    {

        public List<GameObject> bots = new List<GameObject>();

        [Space(40)]
        public Transform Red;
        public Transform Yellow;
        public Transform Green;
        public Transform Blue;
        public Transform Orange;
        public Transform Violet;



        void Start()
        {

        }


        void Update()
        {

        }
    }
}


using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace warehouse.Core
{
    public class coreChargingPortManager : MonoBehaviour
    {
        public List<GameObject> Charger = new List<GameObject>();
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }

}
